// Student Name: Dathan Dominic Neal
// Student ID: 1218482291
// Date September 24th, 2023

export const generateRandomNumber = function (min, max){
    return Math.floor(Math.random() * (max - min)) + min;
}

